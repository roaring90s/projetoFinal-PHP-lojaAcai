<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!--LINK DO BOOTSTRAP 5-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!--ÍCONES DO BOOTSTRAP-->
    <link rel="icon" href="\ProjetoTCC\img\bank.svg" type="image/x-icon" /> <!--ÍCONE DA PÁGINA-->
    <link rel="preconnect" href="https://fonts.googleapis.com"> <!--LINK GOOGLE FONTS-->
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="\ProjetoTCC\CSS\style.css">
    <title>Dashboard</title>
</head>
<style>
    body {
        background: linear-gradient(45deg, #685080, #6545FF, #CC99FF);
        font-family: "Roboto", sans-serif;
        color: white;
    }

    .chart-container {
        width: 100%;
        height: 100%;
        margin: auto;
    }

    .bg-cards {
        color: white;
        background-color: rgb(49, 11, 85);
        box-shadow: black;
    }
</style>

<body>
    <?php
    include('navbar.php');
    ?>
    <main>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4 py-4">
                    <div class="card bg-cards shadow-lg">
                        <div class="pt-1">
                            <p class="text-center mb-0 text-uppercase">Atualizar Vendas</p>
                        </div>
                        <p class="text-center p-3">
                            <button type="submit" class="btn bg-success"> Adicionar venda <i class="bi bi-plus-circle"></i></button>
                        </p>
                        <p class="text-center">-Registrar Venda</p>
                        <p class="text-center">-Atualizar Venda</p>
                        <p class="text-center">-Excluir Venda</p>
                    </div>
                </div>
                <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4 py-4">
                    <div class="card bg-cards shadow-lg">
                        <div class="card-header p-3 pt-2">
                            <div class="icon icon-lg icon-shape bg-success border-2 m-2 rounded p-2 position-absolute">
                                <i class="bi bi-cash"></i>
                            </div>
                            <div class="text-end pt-1">
                                <p class="text-sm mb-0 text-capitalize">Dinheiro ganho hoje</p>
                                <h4 class="mb-0">R$ 950.00</h4>
                            </div>
                        </div>
                        <hr class="dark-horizontal my-0">
                        <div class="card-footer p-2">
                            <p class="d-inline-flex gap-1">
                                <button class="btn btn-primary m-2" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapse1" aria-expanded="false" aria-controls="collapseExample">
                                    Detalhes de hoje
                                </button>
                            </p>
                            <div class="collapse" id="collapse1">
                                <div class="card card-body bg-cards">
                                    <p>Rosa: <span class="badge bg-danger">R$ 88,90</span></p>
                                    <p>IFood: <span class="badge bg-danger"> R$ 769,20</span></p>
                                    <p>Lucas <span class="badge bg-danger"> R$ 32,10</span></p>
                                    <p>Tiago <span class="badge bg-danger"> R$ 16,40</span></p>
                                    <p>Anna <span class="badge bg-danger">R$ 29,50</span></p>
                                    <p>Lisangela <span class="badge bg-danger"> R$ 13,90</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4 py-4">
                    <div class="card bg-cards shadow-lg">
                        <div class="card-header p-3 pt-2">
                            <div class="icon icon-lg icon-shape bg-primary border-2 m-2 p-2 rounded position-absolute">
                                <i class="bi bi-file-person"></i>
                            </div>
                            <div class="text-end pt-1">
                                <p class="text-sm mb-0 text-capitalize">Metas Mensais</p>
                                <h4>25%</h4>
                            </div>
                        </div>
                        <hr class="dark-horizontal my-0">
                        <div class="card-footer p-3">
                            <p class="mb-0">
                            <div class="progress" role="progressbar" aria-label="Animated striped" aria-valuenow="25"
                                aria-valuemin="0" aria-valuemax="100">
                                <div class="progress-bar progress-bar-striped progress-bar-animated bg-success"
                                    style="width: 25%"></div>
                            </div>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4 py-4">
                    <div class="card bg-cards shadow-lg">
                        <div class="card-header p-3 pt-2">
                            <div class="icon icon-lg icon-shape bg-danger m-2 p-2 rounded position-absolute">
                                <i class="bi bi-receipt"></i>
                            </div>
                            <div class="text-end pt-1">
                                <p class="text-sm mb-0 text-capitalize"> Vendas realizadas </p>
                                <h4 class="mb-0"> 68 </h4>
                            </div>
                        </div>
                        <hr class="dark-horizontal my-0">
                        <div class="card-footer p-3">
                            <p class="mb-0"><span class="badge bg-danger">-%5</span> que semana passada</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4 py-4">
                    <div class="card bg-cards shadow-lg">
                        <div class="card-header p-3 pt-2">
                            <div class="icon icon-lg icon-shape bg-warning m-2 p-2 rounded  position-absolute">
                                <i class="bi bi-receipt-cutoff"></i>
                            </div>
                            <div class="text-end pt-1">
                                <p class="text-sm mb-0 text-capitalize">Total de vendas do mês</p>
                                <h4 class="mb-0">369</h4>
                            </div>
                        </div>
                        <hr class="dark-horizontal my-0">
                        <div class="card-footer p-3">
                            <p class="mb-0"><span class="badge bg-success">+%40</span> que semana passada</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4 py-4">
                    <div class="card bg-cards shadow-lg">
                        <div class="card-header p-3 pt-2">
                            <div class="icon icon-lg icon-shape bg-warning m-2 p-2 rounded  position-absolute">
                                <i class="bi bi-receipt-cutoff"></i>
                            </div>
                            <div class="text-end pt-1">
                                <p class="text-sm mb-0 text-capitalize">Vendas por tamanho de copo</p>
                                <h4>68</h4>
                            </div>
                        </div>
                        <hr class="dark-horizontal my-0">
                        <div class="card-footer p-3">
                            <div class="card-footer p-2">
                                <p class="d-inline-flex gap-1">
                                    <button class="btn btn-primary m-2" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse2" aria-expanded="true"
                                        aria-controls="collapseExample">
                                        Detalhes de hoje
                                    </button>
                                </p>
                                <div class="collapse" id="collapse2">
                                    <div class="card card-body bg-cards">
                                        <p>200ML: 5</p>
                                        <p>300ML: 10</p>
                                        <p>400ML: 15</p>
                                        <p>500ML: 15</p>
                                        <p>700ML: 23</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4 py-4">
                    <div class="card bg-cards shadow-lg">
                        <div class="card-header p-3 pt-2">
                            <div class="text-center pt-1">
                                <p class="text-sm mb-0 text-capitalize">Satisfação dos Clientes</p>
                            </div>
                        </div>
                        <div class="card-footer p-3">
                            <p class="mb-0"> <canvas id="graph1" class="text-center"></canvas>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <footer class="bg-dark text-white pt-5 pb-4 fixed">
        <!--===============================================RODAPÉ DA PÁGINA===============================================================-->
        <div class="container text-center text-md-left">
            <div class="row text-center text-md-left">
                <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
                    <!--===========================================DIV COM UMA COLUNA DO RODAPÉ=============================================================-->
                    <h5 class="text-uppercase mb-4 font-weight-bold text-white">Rochedo Açaís</h5>
                    <p>Criada em 2020, a Rochedo Açaís foi feita com o intuito e objetivo de servir e entregar os
                        melhores sabores
                        da cidade, prezando sempre pela satisfação do cliente.</p>
                </div>
                <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
                    <!--========================================DIV COM A SEGUNDA COLUNA DO RODAPÉ=========================================================-->
                    <h5 class="text-uppercase mb-4 font-weight-bold text-white">Sobre</h5>
                    <p>
                        <a href="termos.html" class="text-white">Termos de uso</a>
                    </p>
                    <p>
                        <a href="politica.html" class="text-white">Política de privacidade</a>
                    </p>
                    <p>
                        <a href="quem.html" class="text-white">Quem Somos</a>
                    </p>
                </div>
                <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
                    <h5 class="text-uppercase mb-4 font-weight-bold text-white">CONTATO</h5>
                    <!--=====================DIV COM A TERCEIRA COLUNA DO RODAPÉ======================================================-->
                    <p>
                        <i class="bi bi-house"></i> Rochedo Açaís, SH Arniqueiras QS 8 - Taguatingua,Brasília
                    </p>
                    <p>
                        <i class="bi bi-telephone"></i> SAC (61) 98922-5422
                    </p>
                    <p>
                        <i class="bi bi-envelope"></i> acaisroc89@gmail.com
                    </p>
                </div>
            </div>
            <hr class="mb-4">
            <div class="row align-items-center">
                <div class="col-md-7 col-lg-8">
                    <p> Copyright ©2024 Todos os direitos reservados by: <a href="#" style="text-decoration: none;">
                            Rochedo
                            açaís</a></p>
                </div>
                <div class="col-md-5 col-lg-4">
                    <div class="text-center text-md-right">
                        <ul class="list-inline-item">
                            <li class="list-inline-item">
                                <a href="#"><i class="bi bi-facebook"></i></a>
                                <!--==============================ÍCONE REDE SOCIAL 1=========================================-->
                            </li>
                            <li class="list-inline-item">
                                <a href="#"><i class="bi bi-instagram"></i></a>
                                <!--==============================ÍCONE REDE SOCIAL 2=========================================-->
                            </li>
                            <li class="list-inline-item">
                                <a href="#"><i class="bi bi-twitter-x"></i></a>
                                <!--==============================ÍCONE REDE SOCIAL 3=========================================-->
                            </li>
                            <li class="list-inline-item">
                                <a href="#"><i class="bi bi-youtube"></i></a>
                                <!--==============================ÍCONE REDE SOCIAL 4=========================================-->
                            </li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </footer>
    <!--=============================================================FIM DO RODAPÉ======================================================================================-->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script> <!--SCRIPT PARA ALGUMAS INTERATIVIDADES DO BOOTSTRAP 5-->
    <script src="\ProjetoTCC\JS\script.js"></script>
</body>

</html>