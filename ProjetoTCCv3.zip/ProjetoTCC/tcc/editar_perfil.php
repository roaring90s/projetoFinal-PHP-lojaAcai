<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!--LINK DO BOOTSTRAP 5-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!--íCONES DO BOOTSTRAP-->
    <link rel="icon" href="\ProjetoTCC\img\berry.png" type="image/x-icon" /> <!--�CONE DA P�GINA-->
    <link rel="preconnect" href="https://fonts.googleapis.com"> <!--LINK GOOGLE FONTS-->
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
        rel="stylesheet">
    <title>Editar Perfil</title>
</head>
<style>
       body {
      /* CONFIGURAÇÃO DO CORPO DA PÁGINA */
      background: linear-gradient(45deg, #685080, #6545FF, #CC99FF);
      font-family: "Roboto", sans-serif;
      color: white;
    }
</style>

<body>
    <?php
    include 'navbar.php';
    ?>
    <main>
        <div class="container text-center py-2">
            <h1>Edite o seu perfil</h1>
            <form action="" method="post">
                <div class="container py-2">
                    <p><label for="nome">Nome:</label>
                        <input type="text" name="nome" id="" class="rounded">
                    </p>
                    <p><label for="email">E-mail:</label>
                        <input type="text" name="email" id="" class="rounded">
                    </p>
                    <p><label for="endereco">Endereço:</label>
                        <input type="text" name="endereco" id="" class="rounded">
                    </p>
                    <button type="submit" class="btn btn-primary">Alterar</button>
                </div>
            </form>
        </div>
    </main>
    <?php
    include 'footer.php';
    ?>
</body>

</html>