<?php
$localhost = "localhost";
$usuario = "root";
$senha = "";
$database = "acai";

$conexao = new mysqli(hostname: "$localhost", username: "$usuario", password: "$senha", database: "$database");

if ($conexao->connect_error) {
    die("Conexão falhou: " . $conexao->connect_error);
}

$usuario = $_POST['usuario'];
$senha = $_POST['senha'];

$sql = "SELECT * FROM usuarios WHERE login = '$usuario' AND senha= '$senha' ";
$resultado = $conexao->query(query: $sql);

if ($resultado->num_rows > 0) {
    session_start();
    $_SESSION['usuario'] = $usuario;
    echo 'Login feito com sucesso!';
    header(header: "Location: editar_perfil.php ");
} else {
    echo "Nome ou senha errados.";
}

$conexao->close();

?>