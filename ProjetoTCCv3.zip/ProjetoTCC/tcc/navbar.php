
  <nav class="navbar bg-light navbar-expand-sm py-1 ">
    <div class="container">
      <a href="index.php" class="navbar-brand d-flex align-items-center">
        <img src="\ProjetoTCC\img\LOGO-Rochedo2.ai.png" alt="Logo Rochedo Açaí" height="20%" width="20%">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menuNavbar"><span
          class="navbar-toggler-icon"></span></button>
      <div class="collapse navbar-collapse" id="menuNavbar">
        <div class="navbar-nav">
          <a href="index.php" class="nav-link">Ínicio</a>
          <a href="pedido.php" class="nav-link">Cardápio</a>
          <a href="login.php" class="nav-link">Login<i class="bi bi-person-fill"></i></a>
        </div>
      </div>
    </div>
  </nav>